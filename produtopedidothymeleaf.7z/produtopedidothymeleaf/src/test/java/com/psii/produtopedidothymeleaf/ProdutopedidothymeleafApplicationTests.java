package com.psii.produtopedidothymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProdutopedidothymeleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
