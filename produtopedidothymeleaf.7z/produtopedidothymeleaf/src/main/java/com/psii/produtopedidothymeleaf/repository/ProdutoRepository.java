package com.psii.produtopedidothymeleaf.repository;

import com.psii.produtopedidothymeleaf.model.Produto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProdutoRepository extends JpaRepository<Produto, Long> {
    
}
