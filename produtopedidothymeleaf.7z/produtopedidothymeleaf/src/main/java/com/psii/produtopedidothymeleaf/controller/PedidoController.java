package com.psii.produtopedidothymeleaf.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.psii.produtopedidothymeleaf.model.Pedido;
import com.psii.produtopedidothymeleaf.model.Produto;
import com.psii.produtopedidothymeleaf.service.PedidoService;
import com.psii.produtopedidothymeleaf.service.ProdutoService;

import java.util.List;

@Controller
public class PedidoController {

    @Autowired
    private PedidoService pedidoService;
    @Autowired
    private ProdutoService produtoService;

    @GetMapping("/cadastrar/pedido")
    public String showCadastroPedido(Model model) {
        model.addAttribute("pedido", new Pedido());
        model.addAttribute("produtos", produtoService.listarProduto()); 
        return "cadastrarPedido"; 
    }

    @PostMapping("/cadastrar/pedido")
    public String cadastrarPedido(@ModelAttribute Pedido pedido) {
        pedidoService.salvarPedido(pedido);
        return "redirect:/listarPedidos";
    }

    @GetMapping("/listarPedidos")
    public String listarPedidos(Model model) {
        List<Pedido> pedidos = pedidoService.listarPedidos();
        List<Produto> produtos = produtoService.listarProduto(); 
        model.addAttribute("pedidos", pedidos);
        model.addAttribute("produtos", produtos);
        return "listarPedidos";
    }

    @GetMapping("/pedido/{id}")
    public ResponseEntity<Pedido> obterPedido(@PathVariable Long id) {
        Pedido pedido = pedidoService.buscarPorId(id);
        return new ResponseEntity<>(pedido, HttpStatus.OK);
    }

    @PostMapping("/pedido/deletar/{id}")
    public String deletarPedido(@PathVariable Long id) {
        pedidoService.deletarPorId(id);
        return "redirect:/listarPedidos";
    }

    @GetMapping("/pedido/editar/{id}")
    public String mostrarFormularioEdicao(@PathVariable Long id, Model model) {
        model.addAttribute("produtos", produtoService.listarProduto()); 
        Pedido pedido = pedidoService.buscarPorId(id);
        model.addAttribute("pedido", pedido);
        return "editarPedido";
    }

    @PostMapping("/pedido/editar")
    public String editarPedido(@ModelAttribute Pedido pedido) {
        pedidoService.salvarPedido(pedido);
        return "redirect:/listarPedidos";
    }
}